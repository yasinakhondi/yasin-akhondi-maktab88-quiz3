let getinput = document.querySelector(input)


// input.oninput = function () {
//     console.log(input.value);
// }